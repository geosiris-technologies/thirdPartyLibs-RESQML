# Where-to-post summary:
- How do I? Why do you? When will you? -> Forum : https://discourse.f2i-consulting.com/c/fesapi
- I got this error, why? -> Forum : https://discourse.f2i-consulting.com/c/fesapi
- I got this error and I'm sure it's a bug -> add a [bug report](https://github.com/F2I-Consulting/fesapi/issues/new/choose) by filling out the related blanks!
- I have a request -> add a [feature request](https://github.com/F2I-Consulting/fesapi/issues/new/choose) by filling out the related blanks!
